create trigger TABLEUPDATE
    after update of TABLESECTION
    on WAITERSTABLESECTION
    for each row
BEGIN
	UPDATE WaitersInfo SET tableSection = :new.tableSection WHERE tableSection = :old.tableSection;
END;
/

