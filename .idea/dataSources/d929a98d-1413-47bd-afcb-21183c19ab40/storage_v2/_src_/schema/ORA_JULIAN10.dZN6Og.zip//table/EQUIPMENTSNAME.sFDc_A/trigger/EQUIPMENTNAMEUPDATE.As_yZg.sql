create trigger EQUIPMENTNAMEUPDATE
    after update of NAME
    on EQUIPMENTSNAME
    for each row
BEGIN
	UPDATE EquipmentsMain SET name = :new.name WHERE name = :old.name;
END;
/

