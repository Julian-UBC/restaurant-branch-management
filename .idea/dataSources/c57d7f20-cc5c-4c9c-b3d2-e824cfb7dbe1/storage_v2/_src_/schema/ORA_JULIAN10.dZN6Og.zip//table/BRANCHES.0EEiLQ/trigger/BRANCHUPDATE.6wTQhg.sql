create trigger BRANCHUPDATE
    after update of LOCID
    on BRANCHES
    for each row
BEGIN
	UPDATE MenuServed SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE WaitersInfo SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE ChefInfo SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE Hosts SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE Managers SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE EquipmentContained SET locID = :new.locID WHERE locID = :old.locID;
	UPDATE Reservations SET locID = :new.locID WHERE locID = :old.locID;
END;
/

