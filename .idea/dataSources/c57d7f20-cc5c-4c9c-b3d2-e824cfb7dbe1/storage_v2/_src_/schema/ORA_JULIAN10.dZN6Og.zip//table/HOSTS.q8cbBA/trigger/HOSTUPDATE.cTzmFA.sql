create trigger HOSTUPDATE
    after update of WID
    on HOSTS
    for each row
BEGIN
	UPDATE Reservations SET wID = :new.wID WHERE wID = :old.wID;
END;
/

