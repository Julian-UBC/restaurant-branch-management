create trigger INGREDIENTSUPDATE
    after update of NAME
    on INGREDIENTS
    for each row
BEGIN
	UPDATE IngredientsRequired SET ingredientsName = :new.name WHERE ingredientsName = :old.name;
END;
/

