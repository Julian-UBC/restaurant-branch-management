create trigger CUSTOMERUPDATE
    after update of CID
    on CUSTOMERS
    for each row
BEGIN
	UPDATE MembershipSubscribes SET cID = :new.cID WHERE cID = :old.cID;
	UPDATE Reservations SET cID = :new.cID WHERE cID = :old.cID;
END;
/

