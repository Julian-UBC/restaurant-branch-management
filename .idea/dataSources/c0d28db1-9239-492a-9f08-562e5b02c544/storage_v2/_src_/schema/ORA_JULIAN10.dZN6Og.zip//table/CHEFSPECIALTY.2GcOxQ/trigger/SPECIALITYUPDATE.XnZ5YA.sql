create trigger SPECIALITYUPDATE
    after update of SPECIALTY
    on CHEFSPECIALTY
    for each row
BEGIN
	UPDATE ChefInfo SET specialty = :new.specialty WHERE specialty = :old.specialty;
END;
/

