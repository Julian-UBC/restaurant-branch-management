create trigger MENUUPDATE
    after update of NAME
    on MENU
    for each row
BEGIN
	UPDATE IngredientsRequired SET menuName = :new.name WHERE menuName = :old.name;
	UPDATE MenuServed SET menuName = :new.name WHERE menuName = :old.name;
END;
/

