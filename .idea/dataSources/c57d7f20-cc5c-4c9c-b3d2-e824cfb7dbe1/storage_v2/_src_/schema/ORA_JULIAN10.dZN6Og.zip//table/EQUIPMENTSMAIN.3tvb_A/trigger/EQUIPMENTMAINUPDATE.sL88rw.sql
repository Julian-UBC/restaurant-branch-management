create trigger EQUIPMENTMAINUPDATE
    after update of ID
    on EQUIPMENTSMAIN
    for each row
BEGIN
	UPDATE EquipmentContained SET equipID = :new.id WHERE equipID = :old.id;
END;
/

